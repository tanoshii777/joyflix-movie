// global.d.ts
declare module "jsonwebtoken";
