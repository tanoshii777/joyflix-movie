import { NextResponse } from "next/server"
import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"
import dbConnect from "@/lib/dbConnect"
import User from "@/models/User"

const loginAttempts = new Map<string, { count: number; lastAttempt: number }>()
const MAX_ATTEMPTS = 5
const LOCKOUT_TIME = 15 * 60 * 1000 // 15 minutes

export async function POST(req: Request) {
  try {
    await dbConnect()
    const { identifier, password, rememberMe } = await req.json()

    if (!identifier || !password) {
      return NextResponse.json({ error: "Email/username and password are required" }, { status: 400 })
    }

    const clientIP = req.headers.get("x-forwarded-for") || "unknown"
    const attempts = loginAttempts.get(clientIP)

    if (attempts && attempts.count >= MAX_ATTEMPTS) {
      const timeSinceLastAttempt = Date.now() - attempts.lastAttempt
      if (timeSinceLastAttempt < LOCKOUT_TIME) {
        const remainingTime = Math.ceil((LOCKOUT_TIME - timeSinceLastAttempt) / 60000)
        return NextResponse.json(
          { error: `Too many login attempts. Please try again in ${remainingTime} minutes.` },
          { status: 429 },
        )
      } else {
        // Reset attempts after lockout period
        loginAttempts.delete(clientIP)
      }
    }

    const user = await User.findOne({
      $or: [{ email: identifier }, { username: identifier }],
    })

    if (!user) {
      const currentAttempts = loginAttempts.get(clientIP) || { count: 0, lastAttempt: 0 }
      loginAttempts.set(clientIP, {
        count: currentAttempts.count + 1,
        lastAttempt: Date.now(),
      })

      return NextResponse.json(
        {
          error: "Invalid email/username or password. Please check your credentials and try again.",
        },
        { status: 401 },
      )
    }

    const isMatch = await bcrypt.compare(password, user.password)
    if (!isMatch) {
      const currentAttempts = loginAttempts.get(clientIP) || { count: 0, lastAttempt: 0 }
      loginAttempts.set(clientIP, {
        count: currentAttempts.count + 1,
        lastAttempt: Date.now(),
      })

      return NextResponse.json(
        {
          error: "Invalid email/username or password. Please check your credentials and try again.",
        },
        { status: 401 },
      )
    }

    loginAttempts.delete(clientIP)

    const tokenExpiry = rememberMe ? "30d" : "7d"
    const token = jwt.sign(
      {
        id: user._id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        loginTime: Date.now(),
      },
      process.env.JWT_SECRET!,
      { expiresIn: tokenExpiry },
    )

    await User.findByIdAndUpdate(user._id, {
      lastLogin: new Date(),
      $inc: { loginCount: 1 },
    })

    const response = NextResponse.json(
      {
        success: true,
        message: `Welcome back, ${user.fullName}! You have successfully logged in.`,
        user: {
          id: user._id,
          username: user.username,
          fullName: user.fullName,
          email: user.email,
          profileImage: user.profileImage,
          theme: user.theme,
        },
      },
      { status: 200 },
    )

    const cookieMaxAge = rememberMe ? 30 * 24 * 60 * 60 : 7 * 24 * 60 * 60 // 30 days or 7 days
    response.cookies.set("token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: cookieMaxAge,
    })

    response.cookies.set("user_theme", user.theme, {
      httpOnly: false,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: cookieMaxAge,
    })

    return response
  } catch (error: any) {
    console.error("Login error:", error)
    return NextResponse.json(
      {
        error: "An unexpected error occurred. Please try again later.",
      },
      { status: 500 },
    )
  }
}
