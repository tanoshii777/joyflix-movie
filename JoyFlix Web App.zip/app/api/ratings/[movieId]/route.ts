import { type NextRequest, NextResponse } from "next/server"
import jwt from "jsonwebtoken"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export async function DELETE(request: NextRequest, { params }: { params: { movieId: string } }) {
  try {
    const token = request.cookies.get("token")?.value
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = jwt.verify(token, JWT_SECRET) as any
    const userId = decoded.userId
    const movieId = params.movieId

    // In a real app, this would delete from database

    return NextResponse.json({
      success: true,
      message: "Rating removed successfully",
      movieId,
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to remove rating" }, { status: 500 })
  }
}
