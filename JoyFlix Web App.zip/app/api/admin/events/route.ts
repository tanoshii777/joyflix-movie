import type { NextRequest } from "next/server"
import dbConnect from "@/lib/db"
import MovieRequest from "@/models/MovieRequest"

export async function GET(request: NextRequest) {
  console.log("[v0] SSE connection established for admin dashboard")

  const encoder = new TextEncoder()

  const stream = new ReadableStream({
    start(controller) {
      // Send initial connection confirmation
      const data = `data: ${JSON.stringify({ type: "connected", timestamp: new Date().toISOString() })}\n\n`
      controller.enqueue(encoder.encode(data))

      // Set up polling for database changes (every 5 seconds)
      const interval = setInterval(async () => {
        try {
          await dbConnect()
          const requests = await MovieRequest.find({}).sort({ createdAt: -1 })

          const updateData = `data: ${JSON.stringify({
            type: "requests_update",
            requests,
            timestamp: new Date().toISOString(),
          })}\n\n`

          controller.enqueue(encoder.encode(updateData))
        } catch (error) {
          console.error("[v0] SSE polling error:", error)
          const errorData = `data: ${JSON.stringify({
            type: "error",
            message: "Database connection failed",
            timestamp: new Date().toISOString(),
          })}\n\n`
          controller.enqueue(encoder.encode(errorData))
        }
      }, 5000) // Poll every 5 seconds instead of 30

      // Cleanup on connection close
      request.signal.addEventListener("abort", () => {
        console.log("[v0] SSE connection closed")
        clearInterval(interval)
        controller.close()
      })
    },
  })

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Cache-Control",
    },
  })
}
