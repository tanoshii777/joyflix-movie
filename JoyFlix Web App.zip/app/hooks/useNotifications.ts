"use client"

import { useState, useEffect } from "react"
import { toast } from "sonner"

interface Notification {
  id: string
  userId: string
  type: "info" | "success" | "warning" | "error" | "movie_request" | "movie_available" | "system"
  title: string
  message: string
  data?: any
  read: boolean
  createdAt: string
}

export function useNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(false)
  const [unreadCount, setUnreadCount] = useState(0)

  const fetchNotifications = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/notifications/in-app")
      if (response.ok) {
        const data = await response.json()
        setNotifications(data.notifications)
        setUnreadCount(data.notifications.filter((n: Notification) => !n.read).length)
      }
    } catch (error) {
      console.error("Failed to fetch notifications:", error)
    } finally {
      setLoading(false)
    }
  }

  const markAsRead = async (notificationId: string) => {
    try {
      const response = await fetch("/api/notifications/in-app", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notificationId, read: true }),
      })

      if (response.ok) {
        setNotifications((prev) => prev.map((n) => (n.id === notificationId ? { ...n, read: true } : n)))
        setUnreadCount((prev) => Math.max(0, prev - 1))
      }
    } catch (error) {
      console.error("Failed to mark notification as read:", error)
    }
  }

  const markAllAsRead = async () => {
    try {
      const unreadNotifications = notifications.filter((n) => !n.read)

      for (const notification of unreadNotifications) {
        await fetch("/api/notifications/in-app", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ notificationId: notification.id, read: true }),
        })
      }

      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
      setUnreadCount(0)
    } catch (error) {
      console.error("Failed to mark all notifications as read:", error)
    }
  }

  const createNotification = async (notification: Omit<Notification, "id" | "read" | "createdAt">) => {
    try {
      const response = await fetch("/api/notifications/in-app", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(notification),
      })

      if (response.ok) {
        fetchNotifications()

        // Show toast notification
        const toastConfig = {
          description: notification.message,
        }

        switch (notification.type) {
          case "success":
            toast.success(notification.title, toastConfig)
            break
          case "error":
            toast.error(notification.title, toastConfig)
            break
          case "warning":
            toast.warning(notification.title, toastConfig)
            break
          default:
            toast.info(notification.title, toastConfig)
        }
      }
    } catch (error) {
      console.error("Failed to create notification:", error)
    }
  }

  useEffect(() => {
    fetchNotifications()
  }, [])

  return {
    notifications,
    loading,
    unreadCount,
    fetchNotifications,
    markAsRead,
    markAllAsRead,
    createNotification,
  }
}
